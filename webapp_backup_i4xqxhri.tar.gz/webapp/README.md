# 📅 Calendar App

एक पूर्ण-featured Calendar Application जिसमें alarm, timer, stopwatch, tasks और notes की सुविधा है।

## ✨ Features

### Home Page (index.html)
- **📆 3 Calendar Views**: Day, Month, Year
- **🎨 5 Soft Color Themes**: Default, Ocean, Lavender, Mint, Peach
- **⚙️ Settings Slider**: Left side में settings button से theme selection
- **📅 Day View**: आज का दिन बड़े font में दिखाई देता है
- **📆 Month View**: पूरा महीना grid में, आज का दिन highlight
- **📊 Year View**: पूरा साल 12 महीनों में
- **🔍 Data Indicator**: हर दिन पर छोटा dot अगर उस दिन data saved है

### Day Details Page (day-details.html)
जब कोई दिन select करते हैं, तो ये features मिलते हैं:

#### 🔔 Alarm
- समय set करें
- Notification मिलेगी set time पर
- Save होता है localStorage में

#### ⏱️ Timer/Countdown
- Hours, Minutes, Seconds set करें
- Start/Stop controls
- समय पूरा होने पर notification

#### ⏲️ Stopwatch
- Start/Pause/Reset functionality
- Accurate time tracking

#### ✅ Tasks
- Task title और time add करें
- Checkbox से complete mark करें
- Delete option
- Time पर notification reminder

#### 📝 Notes
- Rich text notes लिखें
- Save और Clear buttons
- Edit कर सकते हैं बाद में
- localStorage में save होता है

## 🎨 Available Themes

1. **Default** - Purple gradient (नीला-बैंगनी)
2. **Ocean** - Blue gradient (नीला)
3. **Lavender** - Purple-pink gradient (बैंगनी-गुलाबी)
4. **Mint** - Green gradient (हरा)
5. **Peach** - Orange-yellow gradient (नारंगी-पीला)

## 🚀 Usage

### Local Development
```bash
# Simple HTTP server
cd public
python -m http.server 3000

# या npm script से
npm run dev
```

### Deploy to Cloudflare Pages
```bash
npm run deploy
```

## 📱 User Guide

1. **Theme बदलने के लिए**: Top-left में settings button पर क्लिक करें
2. **View बदलने के लिए**: Day, Month, या Year radio button select करें
3. **Navigation**: Arrow buttons या keyboard arrows (←/→) use करें
4. **Day Details खोलने के लिए**: किसी भी दिन पर क्लिक करें
5. **Data Save करने के लिए**: सभी features automatically save होते हैं

## 💾 Data Storage

- सभी data browser के localStorage में save होता है
- हर दिन का data अलग-अलग store होता है
- कोई server की जरूरत नहीं
- Data browser में permanently save रहता है

## 🔔 Notifications

App notification permission मांगेगी:
- Alarm के लिए
- Timer completion के लिए
- Task reminders के लिए

**Note**: Notification permission allow करना जरूरी है इन features के लिए।

## 🌐 Browser Support

- Chrome/Edge: ✅ Full support
- Firefox: ✅ Full support
- Safari: ✅ Full support
- Mobile browsers: ✅ Responsive design

## 📂 Project Structure

```
webapp/
├── public/
│   ├── index.html          # Home page (calendar views)
│   ├── day-details.html    # Day details page (timer, tasks, notes)
│   ├── styles.css          # All styles with themes
│   └── app.js              # Calendar logic
├── package.json
└── README.md
```

## 🎯 Completed Features

✅ Home page with calendar UI
✅ Settings slider with 5 themes
✅ Day/Month/Year views
✅ Day details page
✅ Alarm with notifications
✅ Timer/Countdown
✅ Stopwatch
✅ Task management with reminders
✅ Notes with save/edit
✅ Data persistence (localStorage)
✅ Data indicators on calendar
✅ Responsive design
✅ Keyboard navigation
✅ Hindi language support

## 🚧 Future Enhancements

- Export/Import data
- Recurring tasks
- Calendar sharing
- Dark mode
- Mobile app version
- Cloud sync

## 📄 License

MIT License - Free to use and modify

---

**Made with ❤️ for better time management**
