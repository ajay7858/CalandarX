// Global Variables
let currentView = 'month';
let currentDate = new Date();
const months = [
    'जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून',
    'जुलाई', 'अगस्त', 'सितम्बर', 'अक्टूबर', 'नवम्बर', 'दिसम्बर'
];
const monthsEnglish = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];
const weekdays = ['रवि', 'सोम', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि'];
const weekdaysFull = ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'];

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Load saved theme
    const savedTheme = localStorage.getItem('calendarTheme') || 'default';
    document.body.className = savedTheme + '-theme';
    
    // Set active theme in sidebar
    const themeOptions = document.querySelectorAll('.theme-option');
    themeOptions.forEach(option => {
        if (option.dataset.theme === savedTheme) {
            option.style.opacity = '1';
            option.style.transform = 'scale(1.05)';
        }
    });
    
    // Initialize calendar
    renderCalendar();
});

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}

// Change Theme
function changeTheme(theme) {
    document.body.className = theme + '-theme';
    localStorage.setItem('calendarTheme', theme);
    
    // Update visual feedback
    const themeOptions = document.querySelectorAll('.theme-option');
    themeOptions.forEach(option => {
        if (option.dataset.theme === theme) {
            option.style.opacity = '1';
            option.style.transform = 'scale(1.05)';
        } else {
            option.style.opacity = '0.7';
            option.style.transform = 'scale(1)';
        }
    });
}

// Change View
function changeView(view) {
    currentView = view;
    renderCalendar();
}

// Navigation
function navigatePrev() {
    if (currentView === 'day') {
        currentDate.setDate(currentDate.getDate() - 1);
    } else if (currentView === 'month') {
        currentDate.setMonth(currentDate.getMonth() - 1);
    } else if (currentView === 'year') {
        currentDate.setFullYear(currentDate.getFullYear() - 1);
    }
    renderCalendar();
}

function navigateNext() {
    if (currentView === 'day') {
        currentDate.setDate(currentDate.getDate() + 1);
    } else if (currentView === 'month') {
        currentDate.setMonth(currentDate.getMonth() + 1);
    } else if (currentView === 'year') {
        currentDate.setFullYear(currentDate.getFullYear() + 1);
    }
    renderCalendar();
}

// Render Calendar
function renderCalendar() {
    updateDateDisplay();
    const container = document.getElementById('calendarContainer');
    
    if (currentView === 'day') {
        container.innerHTML = renderDayView();
    } else if (currentView === 'month') {
        container.innerHTML = renderMonthView();
    } else if (currentView === 'year') {
        container.innerHTML = renderYearView();
    }
}

// Update Date Display
function updateDateDisplay() {
    const display = document.getElementById('currentDateDisplay');
    
    if (currentView === 'day') {
        display.textContent = `${currentDate.getDate()} ${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
    } else if (currentView === 'month') {
        display.textContent = `${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
    } else if (currentView === 'year') {
        display.textContent = `${currentDate.getFullYear()}`;
    }
}

// Day View
function renderDayView() {
    const today = new Date();
    const isToday = currentDate.toDateString() === today.toDateString();
    const dayName = weekdaysFull[currentDate.getDay()];
    
    return `
        <div class="day-view" onclick="openDayDetails('${currentDate.toISOString()}')">
            <div class="day-name">${dayName}</div>
            <div class="day-number">${currentDate.getDate()}</div>
            <p style="text-align: center; color: #718096; margin-top: 20px; font-size: 1.1rem;">
                ${isToday ? '📅 आज का दिन' : 'विवरण देखने के लिए क्लिक करें'}
            </p>
        </div>
    `;
}

// Month View
function renderMonthView() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const today = new Date();
    
    // First day of month
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    // Previous month days
    const prevLastDay = new Date(year, month, 0);
    const prevDays = firstDay.getDay();
    
    // Next month days
    const nextDays = 6 - lastDay.getDay();
    
    let html = '<div class="month-view">';
    
    // Weekday headers
    html += '<div class="weekday-header">';
    weekdays.forEach(day => {
        html += `<div class="weekday">${day}</div>`;
    });
    html += '</div>';
    
    // Days grid
    html += '<div class="days-grid">';
    
    // Previous month days
    for (let i = prevDays - 1; i >= 0; i--) {
        const day = prevLastDay.getDate() - i;
        const date = new Date(year, month - 1, day);
        html += `<div class="day-cell other-month">${day}</div>`;
    }
    
    // Current month days
    for (let day = 1; day <= lastDay.getDate(); day++) {
        const date = new Date(year, month, day);
        const isToday = date.toDateString() === today.toDateString();
        const hasData = checkDayHasData(date);
        
        html += `<div class="day-cell ${isToday ? 'today' : ''} ${hasData ? 'has-data' : ''}" 
                      onclick="openDayDetails('${date.toISOString()}')">${day}</div>`;
    }
    
    // Next month days
    for (let day = 1; day <= nextDays; day++) {
        html += `<div class="day-cell other-month">${day}</div>`;
    }
    
    html += '</div></div>';
    
    return html;
}

// Year View
function renderYearView() {
    const year = currentDate.getFullYear();
    const today = new Date();
    
    let html = '<div class="year-view">';
    
    for (let month = 0; month < 12; month++) {
        html += `<div class="mini-month">`;
        html += `<h4>${months[month]}</h4>`;
        
        // Mini weekdays
        html += '<div class="mini-weekdays">';
        weekdays.forEach(day => {
            html += `<div class="mini-weekday">${day}</div>`;
        });
        html += '</div>';
        
        // Mini days
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const prevDays = firstDay.getDay();
        
        html += '<div class="mini-days">';
        
        // Previous month days
        const prevLastDay = new Date(year, month, 0);
        for (let i = prevDays - 1; i >= 0; i--) {
            const day = prevLastDay.getDate() - i;
            html += `<div class="mini-day other-month">${day}</div>`;
        }
        
        // Current month days
        for (let day = 1; day <= lastDay.getDate(); day++) {
            const date = new Date(year, month, day);
            const isToday = date.toDateString() === today.toDateString();
            
            html += `<div class="mini-day ${isToday ? 'today' : ''}" 
                          onclick="openDayDetails('${date.toISOString()}')">${day}</div>`;
        }
        
        // Next month days to fill grid
        const totalCells = prevDays + lastDay.getDate();
        const remainingCells = 35 - totalCells; // 5 rows * 7 days
        for (let day = 1; day <= remainingCells; day++) {
            html += `<div class="mini-day other-month">${day}</div>`;
        }
        
        html += '</div></div>';
    }
    
    html += '</div>';
    
    return html;
}

// Check if day has saved data
function checkDayHasData(date) {
    const dateStr = date.toISOString().split('T')[0];
    const storageKey = `calendar_${dateStr}`;
    const data = localStorage.getItem(storageKey);
    
    if (!data) return false;
    
    try {
        const parsed = JSON.parse(data);
        return (parsed.tasks && parsed.tasks.length > 0) || 
               parsed.notes || 
               parsed.alarm;
    } catch (e) {
        return false;
    }
}

// Open Day Details
function openDayDetails(dateStr) {
    const date = new Date(dateStr);
    const dateParam = date.toISOString().split('T')[0];
    window.location.href = `day-details.html?date=${dateParam}`;
}

// Keyboard Navigation
document.addEventListener('keydown', function(e) {
    if (e.key === 'ArrowLeft') {
        navigatePrev();
    } else if (e.key === 'ArrowRight') {
        navigateNext();
    } else if (e.key === 'Escape') {
        const sidebar = document.getElementById('sidebar');
        if (sidebar.classList.contains('active')) {
            toggleSidebar();
        }
    }
});

// Close sidebar when clicking outside
document.addEventListener('click', function(e) {
    const sidebar = document.getElementById('sidebar');
    const settingsBtn = document.querySelector('.settings-btn');
    
    if (sidebar.classList.contains('active') && 
        !sidebar.contains(e.target) && 
        !settingsBtn.contains(e.target)) {
        toggleSidebar();
    }
});
